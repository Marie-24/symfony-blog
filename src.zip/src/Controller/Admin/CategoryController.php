<?php

namespace App\Controller\Admin;

use App\Entity\Category;
use App\Form\CategoryType;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Routing\Annotation\Route;
/**
     * @Route("/category")
     */
class CategoryController extends Controller
{
    /**
     * @Route("/")
     */
    public function index()
    {
        $repository = $this->getDoctrine()->getRepository(Category::class);
        $categories = $repository->findAll();
        return $this->render('admin/category/index.html.twig', 
                [
           'categories'=>$categories
        ]);
    }

/**
 * @route("/edit")
 */
public function edit(Request $request)
        {
    $em = $this->getDoctrine()->getManager();
    $category = new Category();
    $form = $this->createForm(CategoryType::class, $category);
    $form->handleRequest($request);
    if ($form->isSubmitted()){
        if($form->isValid()){
            $em->persist($category);
            $em->flush();
            //ajout du message flash
            $this->addFlash('success', 'La catégorie a bien été enregistrée');
            //redirection vers la liste
            return $this->redirectToRoute('app_admin_category_index');
        }
    }
    return $this->render(
            'admin/category/edit.html.twig',
            [
              'form'=>$form->createView()  
            ]);
        }
}